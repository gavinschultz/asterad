Asterad, an Asteroids clone for Windows developed in C. Have fun!

Controls:
A           turn left
D           turn right
W           thrust
SPACE       fire
S           start, respawn

Some other undocumented keys include:
F2          toggle sound
F3          show bounding boxes
Q, Esc      quit
Alt-Enter   toggle windowed / full-screen
-           slow time (for the adolescent rush of "bullet time")
+           speed time
O           hit all asteroids (cheat)

When entering a high score use A and D to scroll letters and S to enter a character.
